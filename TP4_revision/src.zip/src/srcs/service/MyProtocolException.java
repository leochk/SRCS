package srcs.service;

public class MyProtocolException extends Exception {
}
