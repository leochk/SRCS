package srcs.service;

import java.io.Serializable;

public class VoidResponse implements Serializable {
}
